function Pears(props) {
      return (
        <h2>I don't like pears, but my friend, {props.friend}, does</h2>
      )
    }
    export default Pears