function Heading() {
    return (
      <h1>This is heading </h1>
    )
  }

  export default Heading