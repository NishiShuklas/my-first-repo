import Toogler from './Toggler';
function App1(){
    return (
        <Toogler/>
    )
}

export default App1;