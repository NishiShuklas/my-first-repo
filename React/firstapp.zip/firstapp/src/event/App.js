import Btn from './Btn'

function App(){
return (
    <Btn/>
)
}
export default App