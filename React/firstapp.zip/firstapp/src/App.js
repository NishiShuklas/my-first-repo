import Btn from './event/Btn';
import TextInputWithFocusButton from './Hooks/refhook';
import AppPrompt from './event/Prompt';
import Word from './Hooks/word';
import PropDrilling from './PropDrilling/PropDrilling';
import AppContext from './ContextAPI/AppContext';
import Usereducer_App from './Reducer/usereducer';
import Calculator from './CourseWrapUp/Calculator';
import App1 from './CourseWrapUp/App1';



function App(){
return (
    <App1/>
)
}
export default App