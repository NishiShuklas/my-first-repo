import { useRef } from 'react'; 
function TextInputWithFocusButton() {
    const inputEl = useRef(null);
    const onButtonClick = () => {
      // `current` points to the mounted text input element
      console.log(inputEl.current.value);
      inputEl.current.focus();
    };
    return (
      <>
        <input value="texted "ref={inputEl} type="text" />
        <button onClick={onButtonClick}>Focus the input</button>
      </>
    );
  }
export default TextInputWithFocusButton  